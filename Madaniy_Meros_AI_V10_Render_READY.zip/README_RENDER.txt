MADANIY MEROS AI V10 — RENDER

1. GitHub repositoryga quyidagi fayllarni yuklang:
   - app.py
   - knowledge_base_full_4.json
   - requirements.txt
   - render.yaml

2. Render'da Web Service yarating.

3. Environment Variables:
   BOT_TOKEN = Telegram bot tokeni
   OPENAI_API_KEY = OpenAI API kaliti
   OPENAI_MODEL = gpt-5-mini

4. Build Command:
   python -m py_compile app.py

5. Start Command:
   python app.py

MUHIM:
846-son qarorning TO'LIQ milliy ro'yxati alohida 846_full.txt sifatida
paketda yo'q, chunki to'liq original ro'yxat fayli mavjud emas edi.
V10 kodi bu faylni topsa avtomatik yuklaydi:
   846_full.txt
   846 04.10.2019.txt
   national_list_846.txt

Shuning uchun 846 ning to'liq va tasdiqlangan matni bo'lsa, uni aynan
shu nomlardan biri bilan loyiha papkasiga qo'shish kerak.
